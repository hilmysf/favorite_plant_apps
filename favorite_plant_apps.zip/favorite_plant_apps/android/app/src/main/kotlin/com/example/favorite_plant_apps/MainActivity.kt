package com.example.favorite_plant_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
